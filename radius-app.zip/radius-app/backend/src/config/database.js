import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

let database;

export function connectDatabase(databasePath) {
  mkdirSync(dirname(databasePath), { recursive: true });
  database = new Database(databasePath);
  database.pragma('journal_mode = WAL');
  return database;
}

export function getDatabase() {
  if (!database) {
    throw new Error('Database has not been initialized');
  }
  return database;
}
