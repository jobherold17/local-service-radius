import { Server } from 'socket.io';
import { env } from './env.js';
import { registerTrackingHandlers } from '../services/trackingService.js';

export function initializeSocket(server) {
  const io = new Server(server, {
    cors: { origin: env.frontendOrigin },
  });

  io.on('connection', (socket) => {
    registerTrackingHandlers(io, socket);
  });

  return io;
}
