import cors from 'cors';
import express from 'express';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { connectDatabase } from './config/database.js';
import { env } from './config/env.js';
import { initializeSocket } from './config/socket.js';
import errorHandler from './middleware/errorHandler.js';
import authRouter from './routes/auth.js';
import bookingsRouter from './routes/bookings.js';
import categoriesRouter from './routes/categories.js';
import locationsRouter from './routes/locations.js';
import providersRouter from './routes/providers.js';
import reviewsRouter from './routes/reviews.js';
import searchRouter from './routes/search.js';
import trackingRouter from './routes/tracking.js';

const currentDirectory = dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer(app);

app.use(cors({ origin: env.frontendOrigin }));
app.use(express.json());
app.get('/api/health', (_request, response) => {
  response.json({ status: 'ok' });
});

app.use('/api/auth', authRouter);
app.use('/api/providers', providersRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/reviews', reviewsRouter);
app.use('/api/categories', categoriesRouter);
app.use('/api/locations', locationsRouter);
app.use('/api/search', searchRouter);
app.use('/api/tracking', trackingRouter);
app.use(errorHandler);

connectDatabase(resolve(currentDirectory, '../../', env.databasePath));
initializeSocket(server);
server.listen(env.port, () => {
  console.log(`Radius API listening on http://localhost:${env.port}`);
});
