import { Router } from 'express';

const router = Router();
router.all('/', (_request, response) => response.status(501).json({ error: 'Provider routes are not implemented' }));

export default router;
