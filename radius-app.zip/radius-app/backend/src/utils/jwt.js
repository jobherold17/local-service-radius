import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export function createToken(payload, options = {}) {
  return jwt.sign(payload, env.jwtSecret, { expiresIn: '7d', ...options });
}
