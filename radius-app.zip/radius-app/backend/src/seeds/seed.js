import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import { connectDatabase } from '../config/database.js';
import { env } from '../config/env.js';

const currentDirectory = dirname(fileURLToPath(import.meta.url));
connectDatabase(resolve(currentDirectory, '../../../', env.databasePath));
console.log('Database initialized. Add application seed data here.');
