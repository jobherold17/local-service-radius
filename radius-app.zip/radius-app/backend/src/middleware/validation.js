export function requireFields(...fields) {
  return (request, response, next) => {
    const missingFields = fields.filter((field) => request.body?.[field] == null);
    if (missingFields.length > 0) {
      return response.status(400).json({
        error: 'Required fields are missing',
        fields: missingFields,
      });
    }
    return next();
  };
}
