export function registerTrackingHandlers(io, socket) {
  socket.on('tracking:join', (bookingId) => {
    if (typeof bookingId === 'string' && bookingId.length > 0) {
      socket.join(`booking:${bookingId}`);
    }
  });

  socket.on('tracking:update', (update) => {
    if (!update || typeof update.bookingId !== 'string') return;
    io.to(`booking:${update.bookingId}`).emit('tracking:location', update);
  });
}
